const h1 = document.querySelector("div.hello:first-child h1");



console.dir(h1);

h1.style.color = "white";

function handleh1Click(){
    console.log("h1 was clicked!!")
    h1.style.color = "hotpink";
}

function handleMouseEnter(){
    h1.innerText ="mouse is here!!"
    h1.style.color = "pink"
}
function handlemouseleave(){
    h1.innerText ="mouse run away!!"
    h1.style.color = "white"
}
function handleWindowResize(){
    document.body.style.backgroundColor = "tomato";
} 

function handleWindowCopy(){
    alert("복사 성공 야호");
}
function handleWindowOofline(){
    alert("GOOOOD");
}
function handleWindowOnline(){
    alert("SOO GOOD");
}

h1.addEventListener("click", handleh1Click);
//h1.onclick = hsndleh1Click;
h1.addEventListener("mouseenter", handleMouseEnter);
//h1.onmouseentern = handleMouseEnter;
h1.addEventListener("mouseleave", handlemouseleave);
//h1.onmouseleave = handleMouseLeave;

window.addEventListener("resize", handleWindowResize);
window.addEventListener("copy", handleWindowCopy);
window.addEventListener("offline", handleWindowOofline);
window.addEventListener("online", handleWindowOnline);