
const a = 5;
const b = 2;

console.log(a + b);
console.log(a * b);
console.log(a / b);



const A = 5;
let isNicoFat = true;
isNicoFat = false;
console.log(A, isNicoFat);



// array
const daysOfWeek = ['mon', 'tue', 'wed', 'thu', 'fri', 'sat'];

// get item from array [0,,,3,,4,,]
console.log(daysOfWeek);

// add one mare day to the array
daysOfWeek.push('sun');

console.log(daysOfWeek);



////복습
const toDOList = ['영어 단어외우기','사문탐 수행 준비'];
console.log(toDOList);
toDOList.push('화학 수행 준비');
console.log(toDOList);



// const playerName = 'ol0ga';
// const playerpoints = 121212;
// const playerHP = 80;
// const playerbusy = true;
//// 이것들을 array를 사용해서 

/// player[0] == name
/// player[1] == points
/// player[2] == hp
/// player[3] == busy
//const player = ['ol0ga', 121212, 80, true];

// objects를 사용하여 더 간편하게
const player = {
    name:"ol0ga",
    points: 121212,
    HP: 80,
    busy: true,
}
console.log(player);
player.busy = false;
player.lastname = 'pooo';
player.points = player.points + 15;
console.log(player);

// console.log(player.name);



function sayskull(nameOfPerson, age){
    console.log("skull my name is " + nameOfPerson + " and I'm " + age + "years old");
}

sayskull('pobi', 6);
sayskull('rupi', 90);
sayskull('pororo', 5);




// 1 (pius)
function plus(firstNumber,secondNumber) {
    console.log(firstNumber+secondNumber);
}

// 2 (divide)
function divide(a, b) {
    console.log(a/b);
}

plus (60, 8);
divide (90, 9);
// 60=firstNumber, 8=secondNumber
// a=90, b=9



const players = {
    name: "juju",
    sayfuck: function (otherPersonName) {
        console.log("fuck " + otherPersonName + " go away");
    }
};

console.log(players.name);
players.sayfuck("babi");
players.sayfuck("nico");



const thatplayer = {
    name: "ko gayeong",
    age: 19,
    birth: 20060110,
    favorite: "델리만쥬",
};
console.log(thatplayer);
thatplayer.name = "gogagogi";
console.log(thatplayer);
thatplayer.nickname = "ol0ga";
console.log(thatplayer, console);



function plus() {
    console.log("내일 "+"학교 "+"가기싫어"+"!!!!");
}

plus();
plus();
plus();
plus();


alert("hello")


// 계산기
const calcultor = {
add: function (C, D) {
    console.log(C+D);
},
minus: function (C, D) {
    console.log(C-D);
},
div: function (C, D) {
    console.log(C/D);
},
multi: function (C, D) {
    console.log(C*D);
},
power: function (C, D) {
    console.log(C**D);
},
};
   
calcultor.add(6, 2);
calcultor.minus(6, 2);
calcultor.div(6, 2);
calcultor.multi(6, 2);
calcultor.power(6, 2);



const age = parseInt(prompt("How old are you?"));

if (isNaN(age || age < 0)) {
    console.log("please write a number");
} else if (age < 20) {
    console.log("You are too young");
} else if (age >= 20 && age <= 50) {
    console.log("you can drink"); 
} else if (age > 50 && age <= 80) {
    console.log("You should exercise"); 
} else if (age === 100) {
    console.log("WOW");
} else if (age > 80) {
    console.log("You can do whatever you want");
} else {
    console.log("You can't drink");
}

//||=or,&&=and
//== value를 할당
//=== 같은지 확인 (~가 ~인가?)
//!== 같지않음을 확인(~가 ~이 아닌가?)

// if((m && n) || (o && p) || (q || r)) 