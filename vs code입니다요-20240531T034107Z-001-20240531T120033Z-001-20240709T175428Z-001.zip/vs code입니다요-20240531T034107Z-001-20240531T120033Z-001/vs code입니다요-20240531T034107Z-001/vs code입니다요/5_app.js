const h1 = document.querySelector("div.hello:first-child h1");

//function handleTitleClick(){
//    const currentColor =h1.style.color;
//    let newCoolor;
//    if (currentColor === "lightpink"){
//        newColor = "hotpink";
//    }else{
//        newColor = "lightpink";
//    }
//    h1.style.color = newColor;
//}

function handleTitleClick() {
   // h1.className = "clicked"
   const clickedClass = "clicked";
   if(h1.className === clickedClass){
       h1.className = "";
    } else {
        h1.className = clickedClass;
    }
}

h1.addEventListener("click", handleTitleClick);

// toggle= 토큰을 toggle한다 토큰이 존재한다면 토큰 제거,존재하지않는다면 토큰을 추가
